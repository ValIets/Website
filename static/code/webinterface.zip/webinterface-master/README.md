# Valiets Webinterface

![User list](docs/nl/user-list.jpg)


## Prerequisites

- NPM


## Installation

```sh
# Clone the repository
git clone https://github.com/ValIets/webinterface.git

# Go to directory
cd valiets-webinterface

# Install npm dependencies
npm install

# Pre-process things
npm run production

# Or for development
npm run watch
```


## To-do's

- Use Font Awesome 5 as npm dependency.
