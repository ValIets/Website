export default {
    "server": {
        "ip": "145.132.98.80",
        "port": 51030
    }
}
